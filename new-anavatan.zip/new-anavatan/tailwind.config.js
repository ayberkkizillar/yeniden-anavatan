/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./pages/**/*.{html,js}", "./*.{html,js}"],

  theme: {},
  plugins: [],
};
