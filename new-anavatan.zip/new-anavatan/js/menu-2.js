const menuButton2 = document.querySelector(".menu-2-hamburger-button");
const closeButton2 = document.querySelector(".menu-2-close-button");
const menuContainer2 = document.querySelector(".menu-2");
const overlay2 = document.querySelector(".menu-2-overlay");

menuButton2.addEventListener("click", function () {
  menuContainer2.classList.add("open");
  overlay2.classList.add("active");
});

closeButton2.addEventListener("click", function () {
  menuContainer2.classList.remove("open");
  overlay2.classList.remove("active");
});
overlay2.addEventListener("click", function () {
  menuContainer2.classList.remove("open");
  overlay2.classList.remove("active");
});
