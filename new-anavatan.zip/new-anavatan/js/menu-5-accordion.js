function toggleDetails(detailsId) {
  const detailsElements = document.querySelectorAll("details");
  detailsElements.forEach((details) => {
    if (details.getAttribute("id") !== `details-${detailsId}`) {
      details.removeAttribute("open");
      details.classList.remove("closing");
    }
  });

  const currentDetails = document.getElementById(`details-${detailsId}`);
  currentDetails.toggleAttribute("open");

  if (currentDetails.hasAttribute("open")) {
    currentDetails.classList.remove("closing");
  } else {
    currentDetails.classList.add("closing");
  }
}
