$(document).ready(function () {
  $(".accordion-heading-style-2").click(function () {
    if ($(this).hasClass("accordion-heading-active-style-2")) {
      $(this).removeClass("accordion-heading-active-style-2");
      $(this).next(".accordion-body-style-2").slideUp();
    } else {
      $(".accordion-body-style-2").slideUp();
      $(".accordion-heading-style-2").removeClass("accordion-heading-active-style-2");

      $(this).next(".accordion-body-style-2").slideDown();
      $(this).addClass("accordion-heading-active-style-2");
    }
  });
});
