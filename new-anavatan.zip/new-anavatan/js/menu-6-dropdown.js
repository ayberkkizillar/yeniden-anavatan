let timeoutId;

function showDropdown(show) {
  const dropdownMenu = document.getElementById("dropdown-menu-6");
  clearTimeout(timeoutId);

  if (show) {
    dropdownMenu.classList.remove("hidden");
  } else {
    timeoutId = setTimeout(() => {
      dropdownMenu.classList.add("hidden");
    }, 300);
  }
}

function hideDropdown() {
  clearTimeout(timeoutId);
  timeoutId = setTimeout(() => {
    const dropdownMenu = document.getElementById("dropdown-menu-6");
    dropdownMenu.classList.add("hidden");
  }, 300);
}
