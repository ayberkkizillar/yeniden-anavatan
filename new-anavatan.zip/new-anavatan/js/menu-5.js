const menuButton5 = document.querySelector(".menu-5-hamburger-button");
const closeButton5 = document.querySelector(".menu-5-close-button");
const menuContainer5 = document.querySelector(".menu-5");
const overlay5 = document.querySelector(".menu-5-overlay");

menuButton5.addEventListener("click", function () {
  menuContainer5.classList.add("open");
  overlay5.classList.add("active");
});

closeButton5.addEventListener("click", function () {
  menuContainer5.classList.remove("open");
  overlay5.classList.remove("active");
});
overlay5.addEventListener("click", function () {
  menuContainer5.classList.remove("open");
  overlay5.classList.remove("active");
});
