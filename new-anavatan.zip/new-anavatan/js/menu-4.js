const menuButton4 = document.querySelector(".menu-4-hamburger-button");
const closeButton4 = document.querySelector(".menu-4-close-button");
const menuContainer4 = document.querySelector(".menu-4");
const overlay4 = document.querySelector(".menu-4-overlay");

menuButton4.addEventListener("click", function () {
  menuContainer4.classList.add("open");
  overlay4.classList.add("active");
});

closeButton4.addEventListener("click", function () {
  menuContainer4.classList.remove("open");
  overlay4.classList.remove("active");
});
overlay4.addEventListener("click", function () {
  menuContainer4.classList.remove("open");
  overlay4.classList.remove("active");
});
