const menuButton3 = document.querySelector(".menu-3-hamburger-button");
const closeButton3 = document.querySelector(".menu-3-close-button");
const menuContainer3 = document.querySelector(".menu-3");
const overlay3 = document.querySelector(".menu-3-overlay");

menuButton3.addEventListener("click", function () {
  menuContainer3.classList.add("open");
  overlay3.classList.add("active");
});

closeButton3.addEventListener("click", function () {
  menuContainer3.classList.remove("open");
  overlay3.classList.remove("active");
});
overlay3.addEventListener("click", function () {
  menuContainer3.classList.remove("open");
  overlay3.classList.remove("active");
});
