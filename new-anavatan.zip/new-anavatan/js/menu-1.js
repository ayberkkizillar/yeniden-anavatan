const menuButton = document.querySelector(".menu-1-hamburger-button");
const closeButton = document.querySelector(".menu-1-close-button");
const menuContainer = document.querySelector(".menu-1");
const overlay = document.querySelector(".menu-1-overlay");

menuButton.addEventListener("click", function () {
  menuContainer.classList.add("open");
  overlay.classList.add("active");
});

closeButton.addEventListener("click", function () {
  menuContainer.classList.remove("open");
  overlay.classList.remove("active");
});
overlay.addEventListener("click", function () {
  menuContainer.classList.remove("open");
  overlay.classList.remove("active");
});
