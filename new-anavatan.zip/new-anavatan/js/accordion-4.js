$(document).ready(function () {
  $(".accordion-heading-style-4").click(function () {
    if ($(this).hasClass("accordion-heading-active-style-4")) {
      $(this).removeClass("accordion-heading-active-style-4");
      $(this).next(".accordion-body-style-4").slideUp();
    } else {
      $(".accordion-body-style-4").slideUp();
      $(".accordion-heading-style-4").removeClass("accordion-heading-active-style-4");

      $(this).next(".accordion-body-style-4").slideDown();
      $(this).addClass("accordion-heading-active-style-4");
    }
  });
});
