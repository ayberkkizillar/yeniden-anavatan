$(document).ready(function () {
  $(".accordion-heading").click(function () {
    if ($(this).hasClass("accordion-heading-active")) {
      $(this).removeClass("accordion-heading-active");
      $(this).next(".accordion-body").slideUp();
    } else {
      $(".accordion-body").slideUp();
      $(".accordion-heading").removeClass("accordion-heading-active");

      $(this).next(".accordion-body").slideDown();
      $(this).addClass("accordion-heading-active");
    }
  });
});
